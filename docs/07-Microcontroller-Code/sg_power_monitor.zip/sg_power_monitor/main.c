#include "mcc_generated_files/system/system.h"
#include <stdio.h>
#include <stdbool.h>

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();
    bool isEnergyMode = false;
    int analog_in;
    
    while(1)
    {
        //switch from instantanous power display to energy usage over time
        if(IO_PB_GetValue() == 1)
        {
            isEnergyMode = !isEnergyMode;
            LED1_SetHigh();
            //LED2_SetHigh();
            LED3_SetHigh();
            LED4_SetHigh();
            //waits until button is released
            while(IO_PB_GetValue() == 1);
        } else {
            LED1_SetLow();
            //LED2_SetLow();
            LED3_SetLow();
            LED4_SetLow();
        }
        
        //read analog current sensor value and check if current is being drawn
        ADC_ChannelSelect(ADC_CHANNEL_ANA0);
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        analog_in = ADC_ConversionResultGet();
        printf("%d \r\n",analog_in);
        
        //send cur_debug signal to verify that device is plugged in
        if(analog_in > 700) CUR_D_SetHigh();
        else CUR_D_SetLow();
    }    
}