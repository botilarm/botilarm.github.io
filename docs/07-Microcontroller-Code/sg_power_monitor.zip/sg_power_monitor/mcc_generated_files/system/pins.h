/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define CUR_S_TRIS                 TRISAbits.TRISA0
#define CUR_S_LAT                  LATAbits.LATA0
#define CUR_S_PORT                 PORTAbits.RA0
#define CUR_S_WPU                  WPUAbits.WPUA0
#define CUR_S_OD                   ODCONAbits.ODCA0
#define CUR_S_ANS                  ANSELAbits.ANSELA0
#define CUR_S_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define CUR_S_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define CUR_S_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define CUR_S_GetValue()           PORTAbits.RA0
#define CUR_S_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define CUR_S_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define CUR_S_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define CUR_S_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define CUR_S_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define CUR_S_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define CUR_S_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define CUR_S_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA3 aliases
#define IO_D_TRIS                 TRISAbits.TRISA3
#define IO_D_LAT                  LATAbits.LATA3
#define IO_D_PORT                 PORTAbits.RA3
#define IO_D_WPU                  WPUAbits.WPUA3
#define IO_D_OD                   ODCONAbits.ODCA3
#define IO_D_ANS                  ANSELAbits.ANSELA3
#define IO_D_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define IO_D_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define IO_D_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define IO_D_GetValue()           PORTAbits.RA3
#define IO_D_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define IO_D_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define IO_D_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define IO_D_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define IO_D_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define IO_D_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define IO_D_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define IO_D_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set RA4 aliases
#define IO_DP_TRIS                 TRISAbits.TRISA4
#define IO_DP_LAT                  LATAbits.LATA4
#define IO_DP_PORT                 PORTAbits.RA4
#define IO_DP_WPU                  WPUAbits.WPUA4
#define IO_DP_OD                   ODCONAbits.ODCA4
#define IO_DP_ANS                  ANSELAbits.ANSELA4
#define IO_DP_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define IO_DP_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define IO_DP_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define IO_DP_GetValue()           PORTAbits.RA4
#define IO_DP_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define IO_DP_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define IO_DP_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define IO_DP_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define IO_DP_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define IO_DP_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define IO_DP_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define IO_DP_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RB1 aliases
#define IO_DIG3_TRIS                 TRISBbits.TRISB1
#define IO_DIG3_LAT                  LATBbits.LATB1
#define IO_DIG3_PORT                 PORTBbits.RB1
#define IO_DIG3_WPU                  WPUBbits.WPUB1
#define IO_DIG3_OD                   ODCONBbits.ODCB1
#define IO_DIG3_ANS                  ANSELBbits.ANSELB1
#define IO_DIG3_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define IO_DIG3_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define IO_DIG3_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define IO_DIG3_GetValue()           PORTBbits.RB1
#define IO_DIG3_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define IO_DIG3_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define IO_DIG3_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define IO_DIG3_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define IO_DIG3_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define IO_DIG3_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define IO_DIG3_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define IO_DIG3_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define IO_DIG2_TRIS                 TRISBbits.TRISB2
#define IO_DIG2_LAT                  LATBbits.LATB2
#define IO_DIG2_PORT                 PORTBbits.RB2
#define IO_DIG2_WPU                  WPUBbits.WPUB2
#define IO_DIG2_OD                   ODCONBbits.ODCB2
#define IO_DIG2_ANS                  ANSELBbits.ANSELB2
#define IO_DIG2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define IO_DIG2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define IO_DIG2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define IO_DIG2_GetValue()           PORTBbits.RB2
#define IO_DIG2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define IO_DIG2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define IO_DIG2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define IO_DIG2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define IO_DIG2_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define IO_DIG2_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define IO_DIG2_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define IO_DIG2_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RC2 aliases
#define IO_PB_TRIS                 TRISCbits.TRISC2
#define IO_PB_LAT                  LATCbits.LATC2
#define IO_PB_PORT                 PORTCbits.RC2
#define IO_PB_WPU                  WPUCbits.WPUC2
#define IO_PB_OD                   ODCONCbits.ODCC2
#define IO_PB_ANS                  ANSELCbits.ANSELC2
#define IO_PB_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define IO_PB_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define IO_PB_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define IO_PB_GetValue()           PORTCbits.RC2
#define IO_PB_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define IO_PB_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define IO_PB_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define IO_PB_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define IO_PB_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define IO_PB_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define IO_PB_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define IO_PB_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define IO_DIG1_TRIS                 TRISCbits.TRISC3
#define IO_DIG1_LAT                  LATCbits.LATC3
#define IO_DIG1_PORT                 PORTCbits.RC3
#define IO_DIG1_WPU                  WPUCbits.WPUC3
#define IO_DIG1_OD                   ODCONCbits.ODCC3
#define IO_DIG1_ANS                  ANSELCbits.ANSELC3
#define IO_DIG1_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define IO_DIG1_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define IO_DIG1_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define IO_DIG1_GetValue()           PORTCbits.RC3
#define IO_DIG1_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define IO_DIG1_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define IO_DIG1_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define IO_DIG1_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define IO_DIG1_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define IO_DIG1_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define IO_DIG1_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define IO_DIG1_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define IO_B_TRIS                 TRISCbits.TRISC4
#define IO_B_LAT                  LATCbits.LATC4
#define IO_B_PORT                 PORTCbits.RC4
#define IO_B_WPU                  WPUCbits.WPUC4
#define IO_B_OD                   ODCONCbits.ODCC4
#define IO_B_ANS                  ANSELCbits.ANSELC4
#define IO_B_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define IO_B_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define IO_B_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define IO_B_GetValue()           PORTCbits.RC4
#define IO_B_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define IO_B_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define IO_B_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define IO_B_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define IO_B_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define IO_B_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define IO_B_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define IO_B_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define IO_F_TRIS                 TRISCbits.TRISC5
#define IO_F_LAT                  LATCbits.LATC5
#define IO_F_PORT                 PORTCbits.RC5
#define IO_F_WPU                  WPUCbits.WPUC5
#define IO_F_OD                   ODCONCbits.ODCC5
#define IO_F_ANS                  ANSELCbits.ANSELC5
#define IO_F_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define IO_F_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define IO_F_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define IO_F_GetValue()           PORTCbits.RC5
#define IO_F_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define IO_F_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define IO_F_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define IO_F_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define IO_F_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define IO_F_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define IO_F_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define IO_F_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define IO_A_TRIS                 TRISCbits.TRISC6
#define IO_A_LAT                  LATCbits.LATC6
#define IO_A_PORT                 PORTCbits.RC6
#define IO_A_WPU                  WPUCbits.WPUC6
#define IO_A_OD                   ODCONCbits.ODCC6
#define IO_A_ANS                  ANSELCbits.ANSELC6
#define IO_A_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define IO_A_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define IO_A_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define IO_A_GetValue()           PORTCbits.RC6
#define IO_A_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define IO_A_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define IO_A_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define IO_A_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define IO_A_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define IO_A_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define IO_A_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define IO_A_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define IO_G_TRIS                 TRISCbits.TRISC7
#define IO_G_LAT                  LATCbits.LATC7
#define IO_G_PORT                 PORTCbits.RC7
#define IO_G_WPU                  WPUCbits.WPUC7
#define IO_G_OD                   ODCONCbits.ODCC7
#define IO_G_ANS                  ANSELCbits.ANSELC7
#define IO_G_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define IO_G_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define IO_G_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define IO_G_GetValue()           PORTCbits.RC7
#define IO_G_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define IO_G_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define IO_G_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define IO_G_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define IO_G_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define IO_G_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define IO_G_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define IO_G_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD0 aliases
#define CUR_D_TRIS                 TRISDbits.TRISD0
#define CUR_D_LAT                  LATDbits.LATD0
#define CUR_D_PORT                 PORTDbits.RD0
#define CUR_D_WPU                  WPUDbits.WPUD0
#define CUR_D_OD                   ODCONDbits.ODCD0
#define CUR_D_ANS                  ANSELDbits.ANSELD0
#define CUR_D_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define CUR_D_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define CUR_D_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define CUR_D_GetValue()           PORTDbits.RD0
#define CUR_D_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define CUR_D_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define CUR_D_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define CUR_D_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define CUR_D_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define CUR_D_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define CUR_D_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define CUR_D_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD4 aliases
#define IO_E_TRIS                 TRISDbits.TRISD4
#define IO_E_LAT                  LATDbits.LATD4
#define IO_E_PORT                 PORTDbits.RD4
#define IO_E_WPU                  WPUDbits.WPUD4
#define IO_E_OD                   ODCONDbits.ODCD4
#define IO_E_ANS                  ANSELDbits.ANSELD4
#define IO_E_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define IO_E_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define IO_E_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define IO_E_GetValue()           PORTDbits.RD4
#define IO_E_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define IO_E_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define IO_E_SetPullup()          do { WPUDbits.WPUD4 = 1; } while(0)
#define IO_E_ResetPullup()        do { WPUDbits.WPUD4 = 0; } while(0)
#define IO_E_SetPushPull()        do { ODCONDbits.ODCD4 = 0; } while(0)
#define IO_E_SetOpenDrain()       do { ODCONDbits.ODCD4 = 1; } while(0)
#define IO_E_SetAnalogMode()      do { ANSELDbits.ANSELD4 = 1; } while(0)
#define IO_E_SetDigitalMode()     do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set RD5 aliases
#define LED4_TRIS                 TRISDbits.TRISD5
#define LED4_LAT                  LATDbits.LATD5
#define LED4_PORT                 PORTDbits.RD5
#define LED4_WPU                  WPUDbits.WPUD5
#define LED4_OD                   ODCONDbits.ODCD5
#define LED4_ANS                  ANSELDbits.ANSELD5
#define LED4_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define LED4_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define LED4_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define LED4_GetValue()           PORTDbits.RD5
#define LED4_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define LED4_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define LED4_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define LED4_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define LED4_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define LED4_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define LED4_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define LED4_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define LED3_TRIS                 TRISDbits.TRISD6
#define LED3_LAT                  LATDbits.LATD6
#define LED3_PORT                 PORTDbits.RD6
#define LED3_WPU                  WPUDbits.WPUD6
#define LED3_OD                   ODCONDbits.ODCD6
#define LED3_ANS                  ANSELDbits.ANSELD6
#define LED3_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define LED3_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define LED3_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define LED3_GetValue()           PORTDbits.RD6
#define LED3_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define LED3_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define LED3_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define LED3_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define LED3_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define LED3_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define LED3_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define LED3_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RD7 aliases
#define LED2_TRIS                 TRISDbits.TRISD7
#define LED2_LAT                  LATDbits.LATD7
#define LED2_PORT                 PORTDbits.RD7
#define LED2_WPU                  WPUDbits.WPUD7
#define LED2_OD                   ODCONDbits.ODCD7
#define LED2_ANS                  ANSELDbits.ANSELD7
#define LED2_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define LED2_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define LED2_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define LED2_GetValue()           PORTDbits.RD7
#define LED2_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define LED2_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define LED2_SetPullup()          do { WPUDbits.WPUD7 = 1; } while(0)
#define LED2_ResetPullup()        do { WPUDbits.WPUD7 = 0; } while(0)
#define LED2_SetPushPull()        do { ODCONDbits.ODCD7 = 0; } while(0)
#define LED2_SetOpenDrain()       do { ODCONDbits.ODCD7 = 1; } while(0)
#define LED2_SetAnalogMode()      do { ANSELDbits.ANSELD7 = 1; } while(0)
#define LED2_SetDigitalMode()     do { ANSELDbits.ANSELD7 = 0; } while(0)

// get/set RE2 aliases
#define IO_C_TRIS                 TRISEbits.TRISE2
#define IO_C_LAT                  LATEbits.LATE2
#define IO_C_PORT                 PORTEbits.RE2
#define IO_C_WPU                  WPUEbits.WPUE2
#define IO_C_OD                   ODCONEbits.ODCE2
#define IO_C_ANS                  ANSELEbits.ANSELE2
#define IO_C_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define IO_C_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define IO_C_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define IO_C_GetValue()           PORTEbits.RE2
#define IO_C_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define IO_C_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define IO_C_SetPullup()          do { WPUEbits.WPUE2 = 1; } while(0)
#define IO_C_ResetPullup()        do { WPUEbits.WPUE2 = 0; } while(0)
#define IO_C_SetPushPull()        do { ODCONEbits.ODCE2 = 0; } while(0)
#define IO_C_SetOpenDrain()       do { ODCONEbits.ODCE2 = 1; } while(0)
#define IO_C_SetAnalogMode()      do { ANSELEbits.ANSELE2 = 1; } while(0)
#define IO_C_SetDigitalMode()     do { ANSELEbits.ANSELE2 = 0; } while(0)

// get/set RF0 aliases
#define IO_TX_TRIS                 TRISFbits.TRISF0
#define IO_TX_LAT                  LATFbits.LATF0
#define IO_TX_PORT                 PORTFbits.RF0
#define IO_TX_WPU                  WPUFbits.WPUF0
#define IO_TX_OD                   ODCONFbits.ODCF0
#define IO_TX_ANS                  ANSELFbits.ANSELF0
#define IO_TX_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_TX_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_TX_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_TX_GetValue()           PORTFbits.RF0
#define IO_TX_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_TX_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_TX_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_TX_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_TX_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_TX_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_TX_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_TX_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RX_TRIS                 TRISFbits.TRISF1
#define IO_RX_LAT                  LATFbits.LATF1
#define IO_RX_PORT                 PORTFbits.RF1
#define IO_RX_WPU                  WPUFbits.WPUF1
#define IO_RX_OD                   ODCONFbits.ODCF1
#define IO_RX_ANS                  ANSELFbits.ANSELF1
#define IO_RX_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RX_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RX_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RX_GetValue()           PORTFbits.RF1
#define IO_RX_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RX_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RX_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RX_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RX_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RX_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RX_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RX_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF3 aliases
#define LED1_TRIS                 TRISFbits.TRISF3
#define LED1_LAT                  LATFbits.LATF3
#define LED1_PORT                 PORTFbits.RF3
#define LED1_WPU                  WPUFbits.WPUF3
#define LED1_OD                   ODCONFbits.ODCF3
#define LED1_ANS                  ANSELFbits.ANSELF3
#define LED1_SetHigh()            do { LATFbits.LATF3 = 1; } while(0)
#define LED1_SetLow()             do { LATFbits.LATF3 = 0; } while(0)
#define LED1_Toggle()             do { LATFbits.LATF3 = ~LATFbits.LATF3; } while(0)
#define LED1_GetValue()           PORTFbits.RF3
#define LED1_SetDigitalInput()    do { TRISFbits.TRISF3 = 1; } while(0)
#define LED1_SetDigitalOutput()   do { TRISFbits.TRISF3 = 0; } while(0)
#define LED1_SetPullup()          do { WPUFbits.WPUF3 = 1; } while(0)
#define LED1_ResetPullup()        do { WPUFbits.WPUF3 = 0; } while(0)
#define LED1_SetPushPull()        do { ODCONFbits.ODCF3 = 0; } while(0)
#define LED1_SetOpenDrain()       do { ODCONFbits.ODCF3 = 1; } while(0)
#define LED1_SetAnalogMode()      do { ANSELFbits.ANSELF3 = 1; } while(0)
#define LED1_SetDigitalMode()     do { ANSELFbits.ANSELF3 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/